(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_ea69acce._.js",
  "static/chunks/[next]_internal_font_google_league_spartan_3707755a_module_4846cd8a.css"
],
    source: "dynamic"
});
